import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';
import { logger } from '../utils/logger';

const PLAYWRIGHT_CRX_RESULTS_DIR = path.join(process.cwd(), 'playwright-crx-results');
const PLAYWRIGHT_CRX_REPORTS_DIR = path.join(process.cwd(), 'playwright-crx-reports');

export class PlaywrightCrxService {
  constructor() {
    this.ensureDirectories();
  }

  private ensureDirectories() {
    if (!fs.existsSync(PLAYWRIGHT_CRX_RESULTS_DIR)) {
      fs.mkdirSync(PLAYWRIGHT_CRX_RESULTS_DIR, { recursive: true });
    }
    if (!fs.existsSync(PLAYWRIGHT_CRX_REPORTS_DIR)) {
      fs.mkdirSync(PLAYWRIGHT_CRX_REPORTS_DIR, { recursive: true });
    }
  }

  async startTest(testRunId: string, scriptName: string) {
    try {
      const testData = {
        uuid: testRunId,
        testCaseId: testRunId,
        fullName: scriptName,
        name: scriptName,
        historyId: testRunId,
        start: Date.now(),
        steps: [],
      };

      const resultsPath = path.join(PLAYWRIGHT_CRX_RESULTS_DIR, `${testRunId}-result.json`);
      fs.writeFileSync(resultsPath, JSON.stringify(testData, null, 2));

      return testData;
    } catch (error) {
      logger.error('Error starting Playwright CRX test:', error);
      throw error;
    }
  }

  async recordStep(testId: string, stepName: string, status: 'passed' | 'failed' | 'broken', duration?: number) {
    try {
      const resultsPath = path.join(PLAYWRIGHT_CRX_RESULTS_DIR, `${testId}-result.json`);

      const stepData = {
        name: stepName,
        status,
        statusDetails: {},
        stage: 'finished',
        start: Date.now() - (duration || 0),
        stop: Date.now(),
      };

      let results: any = { steps: [] };
      if (fs.existsSync(resultsPath)) {
        results = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));
      }

      results.steps = results.steps || [];
      results.steps.push(stepData);

      fs.writeFileSync(resultsPath, JSON.stringify(results, null, 2));
    } catch (error) {
      logger.error('Error recording Playwright CRX step:', error);
    }
  }

  async endTest(testId: string, status: 'passed' | 'failed' | 'broken', errorMessage?: string) {
    try {
      const resultsPath = path.join(PLAYWRIGHT_CRX_RESULTS_DIR, `${testId}-result.json`);

      // Read existing data first
      let existing: any = {};
      if (fs.existsSync(resultsPath)) {
        try {
          existing = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));
        } catch (e) {
          logger.warn(`Could not parse existing results for ${testId}, creating new`);
        }
      }

      // Preserve original start time if exists
      const startTime = existing.start || Date.now();
      const stopTime = Date.now();

      const result = {
        uuid: testId,
        historyId: testId,
        testCaseId: testId,
        fullName: existing.fullName || testId,
        name: existing.name || testId,
        status,
        statusDetails: errorMessage ? { message: errorMessage } : {},
        stage: 'finished',
        start: startTime,
        stop: stopTime,
        steps: existing.steps || [],
      };

      // Ensure directory exists
      if (!fs.existsSync(PLAYWRIGHT_CRX_RESULTS_DIR)) {
        fs.mkdirSync(PLAYWRIGHT_CRX_RESULTS_DIR, { recursive: true });
      }

      // Write with explicit flush
      fs.writeFileSync(resultsPath, JSON.stringify(result, null, 2), { encoding: 'utf-8' });
      
      // Verify the write
      const verifyContent = fs.readFileSync(resultsPath, 'utf-8');
      const verifyData = JSON.parse(verifyContent);
      
      if (verifyData.status !== status) {
        logger.error(`Status verification failed! Expected ${status}, got ${verifyData.status}`);
      } else {
        logger.info(`✅ Playwright CRX test ended: ${testId} with status: ${status}`);
      }
    } catch (error) {
      logger.error('❌ Error ending Playwright CRX test:', error);
      throw error; // Re-throw to let caller handle
    }
  }

  async generateReport(testRunId: string): Promise<string> {
    try {
      const reportPath = path.join(PLAYWRIGHT_CRX_REPORTS_DIR, testRunId);

      if (!fs.existsSync(reportPath)) {
        fs.mkdirSync(reportPath, { recursive: true });
      }

      // Copy Playwright CRX logo to report directory
      const logoSourcePath = path.join(process.cwd(), 'playwright-crx-logo.png');
      const logoDestPath = path.join(reportPath, 'playwright-crx-logo.png');
      
      if (fs.existsSync(logoSourcePath)) {
        fs.copyFileSync(logoSourcePath, logoDestPath);
        logger.info(`✅ Copied Playwright CRX logo to report directory`);
      }

      // Check if playwright crx results exist for this test run
      const resultsPath = path.join(PLAYWRIGHT_CRX_RESULTS_DIR, `${testRunId}-result.json`);
      
      // Always try to generate with Allure CLI first for the official report
      try {
        logger.info(`Generating Playwright CRX report with CLI for: ${testRunId}`);
        
        // Fix JAVA_HOME if it ends with \bin
        let javaHome = process.env.JAVA_HOME || '';
        if (javaHome.endsWith('\\bin') || javaHome.endsWith('/bin')) {
          javaHome = path.dirname(javaHome);
          logger.info(`Fixed JAVA_HOME from ${process.env.JAVA_HOME} to ${javaHome}`);
        }
        
        // Use the installed allure-commandline package
        const allureBin = path.join(process.cwd(), 'node_modules', '.bin', 'allure');
        const isWindows = process.platform === 'win32';
        const allureCmd = isWindows ? `"${allureBin}.cmd"` : allureBin;
        
        // Clean old report first
        if (fs.existsSync(reportPath)) {
          fs.rmSync(reportPath, { recursive: true, force: true });
          fs.mkdirSync(reportPath, { recursive: true });
        }
        
        const command = `${allureCmd} generate "${PLAYWRIGHT_CRX_RESULTS_DIR}" -o "${reportPath}" --clean`;
        
        logger.info(`Executing: ${command}`);
        
        const result = execSync(command, {
          cwd: process.cwd(),
          stdio: 'pipe',
          encoding: 'utf-8',
          windowsHide: true,
          env: {
            ...process.env,
            JAVA_HOME: javaHome
          }
        });
        
        logger.info(`Playwright CRX CLI output: ${result}`);
        
        // Verify index.html was created
        const indexPath = path.join(reportPath, 'index.html');
        if (fs.existsSync(indexPath)) {
          // Customize the report title from 'Allure Report' to 'Playwright CRX'
          let htmlContent = fs.readFileSync(indexPath, 'utf-8');
          htmlContent = htmlContent.replace(/<title>Allure Report/g, '<title>Playwright CRX');
          htmlContent = htmlContent.replace(/Allure Report summary mail/g, 'Playwright CRX summary mail');
          
          // Replace Allure text in the UI with Playwright CRX
          htmlContent = htmlContent.replace(/Allure/g, 'Playwright CRX');
          
          // Specifically target the brand text span
          htmlContent = htmlContent.replace(
            /<span class="side-nav__brand-text">Allure<\/span>/g,
            '<span class="side-nav__brand-text">Playwright CRX</span>'
          );
          htmlContent = htmlContent.replace(
            /<span class="side-nav__brand-text">Playwright CRX<\/span>/g,
            '<span class="side-nav__brand-text">Playwright CRX</span>'
          );
          
          // Inject custom CSS and JavaScript to replace logo
          const customCode = `
<style>
/* Replace Allure logo with Playwright CRX logo */
.side-nav__brand {
  background-image: url('playwright-crx-logo.png') !important;
  background-size: contain !important;
  background-repeat: no-repeat !important;
  background-position: center !important;
  width: 200px !important;
  height: 60px !important;
}
.side-nav__brand svg,
.side-nav__brand img {
  display: none !important;
}
/* Hide Allure text in sidebar */
.side-nav__brand::after {
  content: '' !important;
}
</style>
<script>
// Replace Allure branding after page loads
(function() {
  function replaceAllureBranding() {
    // Replace ALL text nodes containing 'Allure' with 'Playwright CRX'
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      null,
      false
    );
    
    const nodesToReplace = [];
    while (walker.nextNode()) {
      const node = walker.currentNode;
      if (node.nodeValue && node.nodeValue.includes('Allure')) {
        nodesToReplace.push(node);
      }
    }
    
    nodesToReplace.forEach(node => {
      node.nodeValue = node.nodeValue.replace(/Allure/g, 'Playwright CRX');
    });
    
    // Replace logo in sidebar
    const brand = document.querySelector('.side-nav__brand');
    if (brand) {
      brand.innerHTML = '<img src="playwright-crx-logo.png" alt="Playwright CRX" style="max-width: 100%; max-height: 100%; object-fit: contain;" />';
    }
    
    // Specifically target the brand text span
    const brandText = document.querySelector('.side-nav__brand-text');
    if (brandText) {
      brandText.textContent = 'Playwright CRX';
    }
    
    // Replace in attributes (like titles, aria-labels, etc.)
    document.querySelectorAll('[title*="Allure"]').forEach(el => {
      el.setAttribute('title', el.getAttribute('title').replace(/Allure/g, 'Playwright CRX'));
    });
    document.querySelectorAll('[aria-label*="Allure"]').forEach(el => {
      el.setAttribute('aria-label', el.getAttribute('aria-label').replace(/Allure/g, 'Playwright CRX'));
    });
  }
  
  // Run immediately
  replaceAllureBranding();
  
  // Run after DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', replaceAllureBranding);
  }
  
  // Run after delays to catch dynamically rendered content
  setTimeout(replaceAllureBranding, 100);
  setTimeout(replaceAllureBranding, 500);
  setTimeout(replaceAllureBranding, 1000);
  setTimeout(replaceAllureBranding, 2000);
  
  // Use MutationObserver to catch any future changes
  const observer = new MutationObserver(() => {
    replaceAllureBranding();
  });
  
  // Start observing after a brief delay
  setTimeout(() => {
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }, 100);
})();
</script>
`;
          htmlContent = htmlContent.replace('</head>', customCode + '</head>');
          
          fs.writeFileSync(indexPath, htmlContent);
          
          // Also update summary.json if it exists
          const summaryPath = path.join(reportPath, 'widgets', 'summary.json');
          if (fs.existsSync(summaryPath)) {
            let summaryContent = fs.readFileSync(summaryPath, 'utf-8');
            summaryContent = summaryContent.replace(/"reportName":"Allure Report"/g, '"reportName":"Playwright CRX"');
            fs.writeFileSync(summaryPath, summaryContent);
          }
          
          // Update export/mail.html if it exists
          const mailPath = path.join(reportPath, 'export', 'mail.html');
          if (fs.existsSync(mailPath)) {
            let mailContent = fs.readFileSync(mailPath, 'utf-8');
            mailContent = mailContent.replace(/Allure Report/g, 'Playwright CRX');
            mailContent = mailContent.replace(/Allure/g, 'Playwright CRX');
            fs.writeFileSync(mailPath, mailContent);
          }
          
          logger.info(`✅ Official Playwright CRX report generated successfully at: ${reportPath}`);
          logger.info(`✅ Branding updated to 'Playwright CRX'`);
          return reportPath;
        } else {
          throw new Error('index.html not generated by Allure CLI');
        }
        
      } catch (execError: any) {
        logger.warn('⚠️ Playwright CRX CLI generation failed, trying fallback...', execError.message);
        logger.warn('Error details:', execError.toString());
        
        // Fallback: Create a basic HTML report
        if (!fs.existsSync(resultsPath)) {
          logger.warn(`No Playwright CRX results found for test run: ${testRunId}, creating empty report`);
          const emptyReportHtml = `<!DOCTYPE html>
<html>
<head><title>Playwright CRX - ${testRunId}</title></head>
<body style="font-family: Arial, sans-serif; margin: 20px;">
<h1>Playwright CRX Report</h1>
<p>Report for test run: ${testRunId}</p>
<p>Status: No test results available</p>
</body>
</html>`;
          fs.writeFileSync(path.join(reportPath, 'index.html'), emptyReportHtml);
          logger.info(`Empty report created at: ${reportPath}`);
          return reportPath;
        }
        
        const resultsData = JSON.parse(fs.readFileSync(resultsPath, 'utf-8'));
        
        const basicReportHtml = `<!DOCTYPE html>
<html>
<head>
  <title>Playwright CRX - ${resultsData.name || testRunId}</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f5f5f5; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .status { padding: 15px; margin: 20px 0; border-radius: 8px; font-weight: bold; }
    .passed { background: #10b981; color: white; }
    .failed { background: #ef4444; color: white; }
    .running { background: #f59e0b; color: white; }
    .step { border-left: 4px solid #667eea; padding: 15px; margin: 10px 0; background: white; border-radius: 4px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .step-status { display: inline-block; padding: 4px 12px; border-radius: 4px; font-size: 12px; font-weight: bold; }
    .step-passed { background: #d1fae5; color: #065f46; }
    .step-failed { background: #fee2e2; color: #991b1b; }
    h1, h2, h3 { margin: 10px 0; }
  </style>
</head>
<body>
  <div class="header">
    <div class="container">
      <h1>🎭 Playwright CRX Test Execution Report</h1>
      <p style="opacity: 0.9;">Test Run ID: ${testRunId}</p>
    </div>
  </div>
  <div class="container">
    <div class="status ${resultsData.status || 'running'}">
      <h2>Status: ${(resultsData.status || 'RUNNING').toUpperCase()}</h2>
    </div>
    <h3>📋 Test Steps (${(resultsData.steps || []).length}):</h3>
    ${(resultsData.steps || []).map((step: any, idx: number) => `
      <div class="step">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <strong>Step ${idx + 1}: ${step.name || 'Unknown step'}</strong>
          <span class="step-status step-${step.status || 'unknown'}">${(step.status || 'N/A').toUpperCase()}</span>
        </div>
        ${step.statusDetails?.message ? `<p style="margin-top: 10px; color: #666;">${step.statusDetails.message}</p>` : ''}
      </div>
    `).join('')}
    ${(resultsData.steps || []).length === 0 ? '<p style="color: #666;">No test steps recorded</p>' : ''}
  </div>
</body>
</html>`;
        
        fs.writeFileSync(path.join(reportPath, 'index.html'), basicReportHtml);
        logger.info(`📄 Fallback HTML report created at: ${reportPath}`);
        return reportPath;
      }
    } catch (error) {
      logger.error('❌ Error generating report:', error);
      throw new Error('Failed to generate report');
    }
  }

  async getReportUrl(testRunId: string): Promise<string> {
    const reportPath = path.join(PLAYWRIGHT_CRX_REPORTS_DIR, testRunId);
    if (fs.existsSync(reportPath)) {
      return `/playwright-crx-reports/${testRunId}/index.html`;
    }
    return '';
  }

  async cleanupOldReports(daysToKeep = 7) {
    try {
      const now = Date.now();
      const maxAge = daysToKeep * 24 * 60 * 60 * 1000;

      const reports = fs.readdirSync(PLAYWRIGHT_CRX_REPORTS_DIR);
      for (const report of reports) {
        const reportPath = path.join(PLAYWRIGHT_CRX_REPORTS_DIR, report);
        const stats = fs.statSync(reportPath);

        if (now - stats.mtimeMs > maxAge) {
          fs.rmSync(reportPath, { recursive: true, force: true });
          logger.info(`Cleaned up old Playwright CRX report: ${report}`);
        }
      }
    } catch (error) {
      logger.error('Error cleaning up Playwright CRX reports:', error);
    }
  }

  getAllReports(): Array<{ id: string; path: string; createdAt: Date }> {
    try {
      const reports = fs.readdirSync(PLAYWRIGHT_CRX_REPORTS_DIR);
      return reports.map(report => {
        const reportPath = path.join(PLAYWRIGHT_CRX_REPORTS_DIR, report);
        const stats = fs.statSync(reportPath);
        return {
          id: report,
          path: `/playwright-crx-reports/${report}/index.html`,
          createdAt: stats.birthtime,
        };
      });
    } catch (error) {
      logger.error('Error getting Playwright CRX reports:', error);
      return [];
    }
  }
}

export const playwrightCrxService = new PlaywrightCrxService();

// Alias for backward compatibility
export const allureService = playwrightCrxService;
